from .vizdoom import __version__ as __version__
from .vizdoom import *

